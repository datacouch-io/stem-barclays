 # AWS Data Engineering Course  # 

**Resources for the free AWS Data Engineering course on youtube**

https://youtu.be/ckQ7d6ca2J0

**Course Material Links**

🖥️[aws booklet](https://aws-dataengineering-day.workshop.aws). ❔[the questionbank](https://www.thequestionbank.io). ℹ️[website](https://johnnychivers.co.uk)


In this free AWS Data Engineering course we take a deep dive into the services provided by AWS to help us with out with our everyday data engineering needs. The course is create for both AWS beginners and seasoned pro’s alike. I have loosely based this course on the AWS Data Engineering Immersion Day. In fact the Kinesis lab is straight out of the Imersion days booklet.  The rest of the labs take the ideas from the booklet, but translates them so we can build our own use cases at home without being in an instructor led environment. During the course we cover AWS Kinesis, AWS DMS and AWS Glue from both a theory and practical perspective. All slides and code are available a GitHub - link above. I will also make all this information free via my website - again link above.
 
😎 About me
I have spent the last decade being immersed in the world of big data working as a consultant for some the globe's biggest companies.My journey into the world of data was not the most conventional. I started my career working as performance analyst in professional sport at the top level's of both rugby and football. I then transitioned into a career in data and computing. This journey culminated in the study of a Masters degree in Software development. Alongside many a professional certification in AWS and MS SQL Server.
