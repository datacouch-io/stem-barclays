SELECT 
*
FROM
"customer_parquet"
